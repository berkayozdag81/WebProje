<?php
    $ad = $_POST["ad"];
    $soyad = $_POST["soyad"];
    $eposta = $_POST["eposta"];
    $telefon = $_POST["telefon"];
    $cinsiyet = $_POST["cinsiyet"];
    $mesaj = $_POST["mesaj"];
    $konu = $_POST["konu"];


    if(isset($ad) != "" && isset($soyad) != "" && isset($eposta) != "" && isset($telefon) != "" &&isset($cinsiyet) != ""&&isset($mesaj) != ""&& isset($konu) != ""){
        echo "isim ". $ad;
        echo "soyisim".$soyad;
        echo "e-posta".$eposta;
        echo "telefon".$telefon;
        echo "cinsiyet".$cinsiyet;
        echo "mesaj".$mesaj;
        echo "konu".$konu;
    }
    else {
        header("Location: iletişim.html");
    }

?>